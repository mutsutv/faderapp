---
name: Other
about: Feature request, question, support request or anything else
title: ''
labels: ''
assignees: ''

---

> There's no template for this issue type. I just wanted to make it clear that it's OK to submit other types of issues.
