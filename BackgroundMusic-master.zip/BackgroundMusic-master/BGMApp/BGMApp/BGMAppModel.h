//
//  BGMAppModel.h
//  FaderControl
//
//  Created by Zahid Usman on 23/11/2022.
//  Copyright © 2022 Background Music contributors. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface BGMAppModel: NSObject
@property (nonatomic, strong) NSString* bundleIdentifier;
//@property (nonatomic, strong) NSApplicationActivationPolicy* activationPolicy;
@property (nonatomic, strong) NSString* title;
@property (nullable, nonatomic, strong) NSData* icon;
@property (nonatomic) pid_t processIdentifier;
@property (nonatomic) int volume;
@property (nonatomic) NSInteger controlNubmer;
@property (nonatomic) NSInteger comboIndex;

- (void) resetControl;
@end

NS_ASSUME_NONNULL_END
