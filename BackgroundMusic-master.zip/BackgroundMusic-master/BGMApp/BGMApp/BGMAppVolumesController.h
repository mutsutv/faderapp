// This file is part of Background Music.
//
// Background Music is free software: you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation, either version 2 of the
// License, or (at your option) any later version.
//
// Background Music is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Background Music. If not, see <http://www.gnu.org/licenses/>.

//
//  BGMAppVolumesController.h
//  BGMApp
//
//  Copyright © 2017 Kyle Neideck
//  Copyright © 2021 Marcus Wu
//

// Local Includes
#import "BGMAudioDeviceManager.h"
#import "BGMAppModel.h"
#import "BGMUserDefaults.h"

// System Includes
#import <Cocoa/Cocoa.h>


#pragma clang assume_nonnull begin

typedef struct BGMAppVolumeAndPan {
    int volume;
    int pan;
} BGMAppVolumeAndPan;

@interface BGMAppVolumesController : NSObject

- (id) initWithMenu:(NSMenu*)menu
      appVolumeView:(NSView*)view
       audioDevices:(BGMAudioDeviceManager*)audioDevices
       appsList:(NSArray<BGMAppModel*>*)apps
      controlNumber:(const NSArray<NSNumber*>*) controls
      userDefaults:(BGMUserDefaults*) defaults;

// See BGMBackgroundMusicDevice::SetAppVolume.
- (void)  setVolume:(SInt32)volume
forAppWithProcessID:(pid_t)processID
           bundleID:(NSString* __nullable)bundleID;

// See BGMBackgroundMusicDevice::SetPanVolume.
- (void) setPanPosition:(SInt32)pan
    forAppWithProcessID:(pid_t)processID
               bundleID:(NSString* __nullable)bundleID;

- (void) setAppVolume:(int) volume forApp:(BGMAppModel*)app;
- (void) setVolumeForApp:(BGMAppModel*)app;
- (BGMAppVolumeAndPan) getVolumeAndPanForApp:(BGMAppModel *)app;
- (void) setVolumeAndPan:(BGMAppVolumeAndPan)volumeAndPan forApp:(BGMAppModel*)app;
- (void) insertMenuItemsForApps:(NSArray<BGMAppModel*>*)apps;
- (void) insertApp:(int) appIndex;
- (void) faderControlSelectionUpdated:(NSUInteger)selectedIndex forAppWithIdentifier:(NSString*)identifier;
- (void) appRemovedFromMenu:(NSString*)identifier;

@end

#pragma clang assume_nonnull end

