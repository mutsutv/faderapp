//
//  BGMAppModel.m
//  FaderControl
//
//  Created by Zahid Usman on 23/11/2022.
//  Copyright © 2022 Background Music contributors. All rights reserved.
//

#import "BGMAppModel.h"

static int const kNoControlNumber = 0;
static int const kAppMaxVolume = 50;

@implementation BGMAppModel
- (instancetype)init {
    self.volume = kAppMaxVolume;
    self.controlNubmer = kNoControlNumber;
    self.processIdentifier = -1;
    self.comboIndex = 0;
    
    return self;
}

- (void)resetControl {
    self.volume = kAppMaxVolume;
    self.controlNubmer = kNoControlNumber;
    self.comboIndex = 0;
}

- (void)encodeWithCoder:(NSCoder *)coder
{
    //Encode properties, other class variables, etc
    [coder encodeObject:self.bundleIdentifier forKey:@"bundleIdentifier"];
    [coder encodeObject:self.title forKey:@"title"];
    [coder encodeObject:self.icon forKey:@"icon"];
    [coder encodeObject:[[NSNumber alloc] initWithInt:self.volume] forKey:@"volume"];
    [coder encodeObject:[[NSNumber alloc] initWithInteger:self.controlNubmer] forKey:@"controlNubmer"];
    [coder encodeObject:[[NSNumber alloc] initWithInteger:self.comboIndex] forKey:@"comboIndex"];
}

- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super init];
    if (self) {
        //decode properties, other class vars
        self.bundleIdentifier = (NSString*) [coder decodeObjectForKey:@"bundleIdentifier"];
        self.title = (NSString*) [coder decodeObjectForKey:@"title"];
        self.icon = (NSData*) [coder decodeObjectForKey:@"icon"];
        NSNumber* vol = (NSNumber*) [coder decodeObjectForKey:@"volume"];
        if (vol == (id)[NSNull alloc]){
            self.volume = kAppMaxVolume;
        } else {
            self.volume = vol.intValue;
        }
        
        NSNumber* cn = (NSNumber*) [coder decodeObjectForKey:@"controlNubmer"];
        if (cn == (id)[NSNull alloc]){
            self.controlNubmer = kNoControlNumber;
        } else {
            self.controlNubmer = cn.integerValue;
        }
        
        NSNumber* cb = (NSNumber*) [coder decodeObjectForKey:@"comboIndex"];
        if (cb == (id)[NSNull alloc]){
            self.comboIndex = kNoControlNumber;
        } else {
            self.comboIndex = cb.integerValue;
        }
    }
    return self;
}
@end
