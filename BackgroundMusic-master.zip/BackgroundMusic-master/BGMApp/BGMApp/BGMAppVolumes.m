// This file is part of Background Music.
//
// Background Music is free software: you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation, either version 2 of the
// License, or (at your option) any later version.
//
// Background Music is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Background Music. If not, see <http://www.gnu.org/licenses/>.

//
//  BGMAppVolumes.m
//  BGMApp
//
//  Copyright © 2016-2020 Kyle Neideck
//  Copyright © 2017 Andrew Tonner
//  Copyright © 2021 Marcus Wu
//  Copyright © 2022 Jon Egan
//

// Self Include
#import "BGMAppVolumes.h"

// Local Includes
#import "BGM_Types.h"
#import "BGM_Utils.h"
#import "BGMAppModel.h"
#import "BGMAppDelegate.h"

// PublicUtility Includes
#import "CADebugMacros.h"


//static float const     kSlidersSnapWithin          = 5;
//static CGFloat const   kAppVolumeViewInitialHeight = 20;
static NSString* const kMoreAppsMenuTitle          = @"More Apps";

@implementation BGMAppVolumes {
    BGMAppVolumesController* controller;

    NSMenu* bgmMenu;
    
    NSView* appVolumeView;
    CGFloat appVolumeViewFullHeight;

    // The number of menu items this class has added to bgmMenu. Doesn't include the More Apps menu.
    NSInteger numMenuItems;
}

- (id) initWithController:(BGMAppVolumesController*)inController
                  bgmMenu:(NSMenu*)inMenu
            appVolumeView:(NSView*)inView {
    if ((self = [super init])) {
        controller = inController;
        bgmMenu = inMenu;
//        moreAppsMenu = [[NSMenu alloc] initWithTitle:kMoreAppsMenuTitle];
        appVolumeView = inView;
        appVolumeViewFullHeight = appVolumeView.frame.size.height;
        numMenuItems = 0;
    }
    
    return self;
}

#pragma mark UI Modifications

- (void) insertMenuItemForApp:(BGMAppModel*)app
                initialVolume:(int)volume
                   initialPan:(int)pan {
    NSMenuItem* appVolItem = [self createBlankAppVolumeMenuItem];

    // Look through the menu item's subviews for the ones we want to set up
    for (NSView* subview in appVolItem.view.subviews) {
        if ([subview conformsToProtocol:@protocol(BGMAppVolumeMenuItemSubview)]) {
            [(NSView<BGMAppVolumeMenuItemSubview>*)subview setUpWithApp:app
                                                                context:self
                                                             controller:controller
                                                               menuItem:appVolItem];
        }
    }

    // Store the NSRunningApplication object with the menu item so when the app closes we can find the item to remove it
    appVolItem.representedObject = app;

    // Set the slider to the volume for this app if we got one from the driver
    [self setVolumeOfMenuItem:appVolItem relativeVolume:volume panPosition:pan];

    // NSMenuItem didn't implement NSAccessibility before OS X SDK 10.12.
#if MAC_OS_X_VERSION_MAX_ALLOWED >= 101200  // MAC_OS_X_VERSION_10_12
    if ([appVolItem respondsToSelector:@selector(setAccessibilityTitle:)]) {
        // TODO: This doesn't show up in Accessibility Inspector for me. Not sure why.
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wpartial-availability"
        appVolItem.accessibilityTitle = [NSString stringWithFormat:@"%@", [app title]];
#pragma clang diagnostic pop
    }
#endif

    // Add the menu item to its menu.
    //if (app.activationPolicy == NSApplicationActivationPolicyRegular) {
        [bgmMenu insertItem:appVolItem atIndex:[self firstMenuItemIndex]];
        numMenuItems++;
    //} else if (app.activationPolicy == NSApplicationActivationPolicyAccessory) {
    //    [moreAppsMenu insertItem:appVolItem atIndex:0];
    //}
}

- (NSMenuItem*) getMenuItemForApp:(NSString*)bundleIdentifier {
//    NSInteger lastAppVolumeMenuItemIndex = [self lastMenuItemIndex] - 1;

    for (NSInteger i = 1; i < bgmMenu.numberOfItems-1; i++) {
        NSMenuItem* item = [bgmMenu itemAtIndex:i];
        BGMAppModel* itemApp = item.representedObject;
        BGMAssert(itemApp, "!itemApp for %s", item.title.UTF8String);

        if ([itemApp.bundleIdentifier isEqual:bundleIdentifier]) {
            return item;
        }
    }
//    for (NSInteger i = 0; i < [moreAppsMenu numberOfItems]; i++) {
//        NSMenuItem* item = [moreAppsMenu itemAtIndex:i];
//        NSRunningApplication* itemApp = item.representedObject;
//        BGMAssert(itemApp, "!itemApp for %s", item.title.UTF8String);
//
//        if ([itemApp isEqual:app]) {
//            return item;
//        }
//    }

    return nil;
}

- (BGMAppVolumeAndPan) getVolumeAndPanForApp:(BGMAppModel*)app {
    BGMAppVolumeAndPan result = {
        .volume = -1,
        .pan = kAppPanNoValue
    };

    NSMenuItem *item = [self getMenuItemForApp:app.bundleIdentifier];

    if (item == nil) {
        return result;
    }
    //Adjust : Adjust if this is called
//    for (NSView* subview in item.view.subviews) {
//        // Get the volume.
//        if ([subview isKindOfClass:[BGMAVM_VolumeSlider class]]) {
//            result.volume = [(BGMAVM_VolumeSlider*)subview intValue];
//        }
//
//        // Get the pan position.
//        if ([subview isKindOfClass:[BGMAVM_PanSlider class]]) {
//            result.pan = [(BGMAVM_PanSlider*)subview intValue];
//        }
//    }

    return result;
}

- (void) updateVolume:(int)percentage forAppWithIdentifier:(NSString*)identifier {
    NSMenuItem *item = [self getMenuItemForApp:identifier];

    if (item == nil) {
        return;
    }
    //Adjust if called
    for (NSView* subview in item.view.subviews) {
        
        // Set the volume.
        if ([subview isKindOfClass:[BGMAVM_AppVolumeLabel class]]) {
            BGMAVM_AppVolumeLabel* label = ((BGMAVM_AppVolumeLabel*) subview);

            label.stringValue = [[[NSString alloc] initWithFormat:@"%d", percentage] stringByAppendingString:@"%"];
            
            if (percentage == 0)
            {
                [label setHidden:YES];
            }else{
                [label setHidden:NO];
            }
        }
        
        if ([subview isKindOfClass:[BGMAVM_AppVolumeMuteIconBox class]]) {
            BGMAVM_AppVolumeMuteIconBox* box = ((BGMAVM_AppVolumeMuteIconBox*) subview);
            
            if (percentage == 0)
            {
                [box setHidden:NO];
                break;
            }else{
                [box setHidden:YES];
                break;
            }
        }
    }
}

- (void)setFaderCombo:(BGMAppModel *)app {
    NSMenuItem *appVolItem = [self getMenuItemForApp:app.bundleIdentifier];

    if (appVolItem == nil) {
        return;
    }

    // Look through the menu item's subviews for the ones we want to set up
    for (NSView* subview in appVolItem.view.subviews) {
        if ([subview isKindOfClass:[BGMAVM_AppFadersComboBox class]]) {
            BGMAVM_AppFadersComboBox* combo = ((BGMAVM_AppFadersComboBox*) subview);
            [combo setStringValue:combo.objectValues[app.comboIndex]];
        }
    }

    appVolItem.representedObject = app;
}


- (void) setVolumeAndPan:(BGMAppVolumeAndPan)volumeAndPan forApp:(BGMAppModel*)app {
    NSMenuItem *item = [self getMenuItemForApp:app.bundleIdentifier];

    if (item == nil) {
        return;
    }
    //Adjust if called
//    for (NSView* subview in item.view.subviews) {
//        // Set the volume.
//        if (volumeAndPan.volume != -1 && [subview isKindOfClass:[BGMAVM_VolumeSlider class]]) {
//            [(BGMAVM_VolumeSlider*)subview setRelativeVolume:volumeAndPan.volume];
//        }
//
//        // Set the pan position.
//        if (volumeAndPan.pan != kAppPanNoValue && [subview isKindOfClass:[BGMAVM_PanSlider class]]) {
//            [(BGMAVM_PanSlider*)subview setPanPosition:volumeAndPan.pan];
//        }
//    }

}

// Create a blank menu item to copy as a template.
- (NSMenuItem*) createBlankAppVolumeMenuItem {
    NSMenuItem* menuItem = [[NSMenuItem alloc] initWithTitle:@"" action:nil keyEquivalent:@""];
    
    menuItem.view = appVolumeView;
    menuItem = [menuItem copy];  // So we can modify a copy of the view, rather than the template itself.
    
    return menuItem;
}

- (void) setVolumeOfMenuItem:(NSMenuItem*)menuItem relativeVolume:(int)volume panPosition:(int)pan {
    // Update the sliders.
    //Adjust: if called
    //for (__unused NSView* subview in menuItem.view.subviews) {
        // Set the volume.
//        if (volume != -1 && [subview isKindOfClass:[BGMAVM_VolumeSlider class]]) {
//            [(BGMAVM_VolumeSlider*)subview setRelativeVolume:volume];
//        }
//
//        // Set the pan position.
//        if (pan != kAppPanNoValue && [subview isKindOfClass:[BGMAVM_PanSlider class]]) {
//            [(BGMAVM_PanSlider*)subview setPanPosition:pan];
//        }
    //}
}

- (NSInteger) firstMenuItemIndex {
    return [self lastMenuItemIndex] - numMenuItems + 1;
}

- (NSInteger) lastMenuItemIndex {
    return [bgmMenu indexOfItemWithTag:kSeparatorBelowVolumesMenuItemTag] - 1;
}

- (void) removeMenuItemForApp:(BGMAppModel*)app {
    // Subtract two extra positions to skip the More Apps menu and the spacer menu item above it.
    NSInteger lastAppVolumeMenuItemIndex = [self lastMenuItemIndex];

    // Check each app volume menu item and remove the item that controls the given app.

    // Look through the main menu.
    for (NSInteger i = [self firstMenuItemIndex]; i <= lastAppVolumeMenuItemIndex; i++) {
        NSMenuItem* item = [bgmMenu itemAtIndex:i];
        BGMAppModel* itemApp = item.representedObject;
        BGMAssert(itemApp, "!itemApp for %s", item.title.UTF8String);

        if ([itemApp.bundleIdentifier isEqual:app.bundleIdentifier]) {
            [bgmMenu removeItem:item];
            numMenuItems--;
            return;
        }
    }

    // Look through the More Apps menu.
//    for (NSInteger i = 0; i < [moreAppsMenu numberOfItems]; i++) {
//        NSMenuItem* item = [moreAppsMenu itemAtIndex:i];
//        NSRunningApplication* itemApp = item.representedObject;
//        BGMAssert(itemApp, "!itemApp for %s", item.title.UTF8String);
//
//        if ([itemApp isEqual:app]) {
//            [moreAppsMenu removeItem:item];
//            return;
//        }
//    }
}

- (void) removeAllAppVolumeMenuItems {
    // Remove all of the menu items this class adds to the menu except for the last two, which are
    // the More Apps menu item and the invisible spacer above it.
    while (numMenuItems > 2) {
        [bgmMenu removeItemAtIndex:[self firstMenuItemIndex]];
        numMenuItems--;
    }

    // The More Apps menu only contains app volume menu items, so we can just remove everything.
//    [moreAppsMenu removeAllItems];
}

- (void)comboBoxSelectionDidChange:(NSNotification *)notification {
    for (NSMenuItem* item in bgmMenu.itemArray)
    {
//        if (![item isKindOfClass:[BGMOutputVolumeMenuItem class]]) {
            BGMAppModel* itemModel = item.representedObject;
            bool isDone = false;
            if (![itemModel isEqual:[NSNull alloc]])
            {
                for (NSView* subview in item.view.subviews)
                {
                    if ([subview isKindOfClass:[NSComboBox class]])
                    {
                        NSComboBox* combo = (NSComboBox*) subview;
                        if (combo == (NSComboBox*)notification.object) {
                            [controller faderControlSelectionUpdated:combo.indexOfSelectedItem forAppWithIdentifier:itemModel.bundleIdentifier];
                            isDone = true;
                            break;
                        }
                    }
                }
            }
            if (isDone)
            {
                break;
            }
//        }
    }
}

- (void) deleteButtonAction : (BGMAVM_AppDeleteButton*) sender  {
    NSAlert *alert = [[NSAlert alloc] init];
    [alert addButtonWithTitle:@"Delete"];
    [alert addButtonWithTitle:@"Cancel"];
    [alert setMessageText:@"Delete the app?"];
    id str = [[NSString alloc] initWithFormat:@"Are you sure you would like to delete the %@?", sender.theApp.title];
    [alert setInformativeText:str];
    [alert setAlertStyle:NSWarningAlertStyle];
    
    if ([alert runModal] == NSAlertFirstButtonReturn) {
        [self removeMenuItemForApp:sender.theApp];
        [controller setVolume:50 forAppWithProcessID:sender.theApp.processIdentifier bundleID:sender.theApp.bundleIdentifier];
        [controller appRemovedFromMenu:sender.theApp.bundleIdentifier];
    }
}

@end

#pragma mark Custom Classes (IB)

// Custom classes for the UI elements in the app volume menu items

@implementation BGMAVM_AppIcon

- (void) setUpWithApp:(BGMAppModel*)app
              context:(BGMAppVolumes*)ctx
           controller:(BGMAppVolumesController*)ctrl
             menuItem:(NSMenuItem*)menuItem {
    #pragma unused (ctx, ctrl, menuItem)
    
    if (app.icon != (id) [NSNull alloc]) {
        self.image = [[NSImage alloc] initWithData:(NSData*) app.icon];
    }

    // Remove the icon from the accessibility hierarchy.
#if MAC_OS_X_VERSION_MAX_ALLOWED >= 101000  // MAC_OS_X_VERSION_10_10
    if ([self.cell respondsToSelector:@selector(setAccessibilityElement:)]) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wpartial-availability"
        self.cell.accessibilityElement = NO;
#pragma clang diagnostic pop
    }
#endif
}

@end

@implementation BGMAVM_AppNameLabel

- (void) setUpWithApp:(BGMAppModel*)app
              context:(BGMAppVolumes*)ctx
           controller:(BGMAppVolumesController*)ctrl
             menuItem:(NSMenuItem*)menuItem {
    #pragma unused (ctx, ctrl, menuItem)
    
    NSString* name = app.title ? (NSString*)app.title : @"";
    self.stringValue = name;
}

@end

@implementation BGMAVM_AppDeleteButton

- (void) setUpWithApp:(BGMAppModel*)app
              context:(BGMAppVolumes*)ctx
           controller:(BGMAppVolumesController*)ctrl
             menuItem:(NSMenuItem*)menuItem {
    #pragma unused (ctx, ctrl, menuItem)
    _theApp = app;
    
    [self setTarget:ctx];
    [self setAction:@selector(deleteButtonAction:)];
}
@end

@implementation BGMAVM_AppVolumeLabel

- (void) setUpWithApp:(BGMAppModel*)app
              context:(BGMAppVolumes*)ctx
           controller:(BGMAppVolumesController*)ctrl
             menuItem:(NSMenuItem*)menuItem {
    #pragma unused (ctx, ctrl, menuItem)
    
    int volume = (int)(((float)app.volume/(float)50)*(float)100);
    NSString* percent = [[[NSString alloc] initWithFormat:@"%d", volume] stringByAppendingString:@"%"];
    self.stringValue = percent;
    
    if (app.volume == 0)
    {
        [self setHidden:YES];
    }else{
        [self setHidden:NO];
    }
}

@end

@implementation BGMAVM_AppVolumeMuteIconBox

- (void) setUpWithApp:(BGMAppModel*)app
              context:(BGMAppVolumes*)ctx
           controller:(BGMAppVolumesController*)ctrl
             menuItem:(NSMenuItem*)menuItem {
    #pragma unused (ctx, ctrl, menuItem)
    
    if (app.volume == 0)
    {
        [self setHidden:NO];
    } else {
        [self setHidden:YES];
    }
}

@end

@implementation BGMAVM_AppFadersComboBox

- (void)setUpWithApp:(BGMAppModel *)app context:(BGMAppVolumes *)ctx controller:(BGMAppVolumesController *)ctrl menuItem:(NSMenuItem *)item {
    self.delegate = ctx;
    
    [self setStringValue:self.objectValues[app.comboIndex]];
}

- (void)setFader:(int)index {
    [self setStringValue:@"Hello"];
}

@end

//@implementation BGMAVM_VolumeSlider {
//    // Will be set to -1 for apps without a pid
//    pid_t appProcessID;
//    NSString* __nullable appBundleID;
//    BGMAppVolumesController* controller;
//}
//
//- (void) setUpWithApp:(BGMAppModel*)app
//              context:(BGMAppVolumes*)ctx
//           controller:(BGMAppVolumesController*)ctrl
//             menuItem:(NSMenuItem*)menuItem {
//    #pragma unused (ctx, menuItem)
//
//    controller = ctrl;
//
//    self.target = self;
//    self.action = @selector(appVolumeChanged);
//
//    appProcessID = app.processIdentifier;
//    appBundleID = app.bundleIdentifier;
//
//    self.maxValue = kAppRelativeVolumeMaxRawValue;
//    self.minValue = kAppRelativeVolumeMinRawValue;
//
//    if ([self respondsToSelector:@selector(setAccessibilityTitle:)]) {
//#pragma clang diagnostic push
//#pragma clang diagnostic ignored "-Wpartial-availability"
//        self.accessibilityTitle = [NSString stringWithFormat:@"Volume for %@", [app title]];
//#pragma clang diagnostic pop
//    }
//}

// We have to handle snapping for volume sliders ourselves because adding a tick mark (snap point) in Interface Builder
// changes how the slider looks.
//- (void) snap {
//    // Snap to the 50% point.
//    float midPoint = (float)((self.maxValue + self.minValue) / 2);
//    if (self.floatValue > (midPoint - kSlidersSnapWithin) && self.floatValue < (midPoint + kSlidersSnapWithin)) {
//        self.floatValue = midPoint;
//    }
//}
//
//- (void) setRelativeVolume:(int)relativeVolume {
//    self.intValue = relativeVolume;
//    [self snap];
//}
//
//- (void) appVolumeChanged {
//    // TODO: This (sending updates to the driver) should probably be rate-limited. It uses a fair bit of CPU for me.
//
//    DebugMsg("BGMAppVolumes::appVolumeChanged: App volume for %s (%d) changed to %d",
//             appBundleID.UTF8String,
//             appProcessID,
//             self.intValue);
//
//    [self snap];
//
//    // The values from our sliders are in
//    // [kAppRelativeVolumeMinRawValue, kAppRelativeVolumeMaxRawValue] already.
//    [controller setVolume:self.intValue forAppWithProcessID:appProcessID bundleID:appBundleID];
//}
//
//@end
//
//@implementation BGMAVM_PanSlider {
//    // Will be set to -1 for apps without a pid
//    pid_t appProcessID;
//    NSString* __nullable appBundleID;
//    BGMAppVolumesController* controller;
//}
//
//- (void) setUpWithApp:(BGMAppModel*)app
//              context:(BGMAppVolumes*)ctx
//           controller:(BGMAppVolumesController*)ctrl
//             menuItem:(NSMenuItem*)menuItem {
//    #pragma unused (ctx, menuItem)
//
//    controller = ctrl;
//
//    self.target = self;
//    self.action = @selector(appPanPositionChanged);
//
//    appProcessID = app.processIdentifier;
//    appBundleID = app.bundleIdentifier;
//
//    self.minValue = kAppPanLeftRawValue;
//    self.maxValue = kAppPanRightRawValue;
//
//    if ([self respondsToSelector:@selector(setAccessibilityTitle:)]) {
//#pragma clang diagnostic push
//#pragma clang diagnostic ignored "-Wpartial-availability"
//        self.accessibilityTitle = [NSString stringWithFormat:@"Pan for %@", [app title]];
//#pragma clang diagnostic pop
//    }
//}
//
//- (void) setPanPosition:(int)panPosition {
//    self.intValue = panPosition;
//}
//
//- (void) appPanPositionChanged {
//    // TODO: This (sending updates to the driver) should probably be rate-limited. It uses a fair bit of CPU for me.
//
//    DebugMsg("BGMAppVolumes::appPanPositionChanged: App pan position for %s changed to %d", appBundleID.UTF8String, self.intValue);
//
//    // The values from our sliders are in [kAppPanLeftRawValue, kAppPanRightRawValue] already.
//    [controller setPanPosition:self.intValue forAppWithProcessID:appProcessID bundleID:appBundleID];
//}
//
//@end
