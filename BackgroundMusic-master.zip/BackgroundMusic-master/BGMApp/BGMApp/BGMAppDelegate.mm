// This file is part of Background Music.
//
// Background Music is free software: you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation, either version 2 of the
// License, or (at your option) any later version.
//
// Background Music is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Background Music. If not, see <http://www.gnu.org/licenses/>.

//
//  BGMAppDelegate.mm
//  BGMApp
//
//  Copyright © 2016-2022 Kyle Neideck
//  Copyright © 2021 Marcus Wu
//

// Self Include
#import "BGMAppDelegate.h"

// Local Includes
#import "BGM_Utils.h"
#import "BGMAppVolumes.h"
#import "BGMAppVolumesController.h"
#import "BGMAutoPauseMusic.h"
#import "BGMAutoPauseMenuItem.h"
#import "BGMDebugLoggingMenuItem.h"
#import "BGMMusicPlayers.h"
#import "BGMOutputDeviceMenuSection.h"
#import "BGMOutputVolumeMenuItem.h"
#import "BGMPreferencesMenu.h"
#import "BGMPreferredOutputDevices.h"
#import "BGMStatusBarItem.h"
#import "BGMSystemSoundsVolume.h"
#import "BGMTermination.h"
#import "BGMUserDefaults.h"
#import "BGMXPCListener.h"
#import "SystemPreferences.h"
#import "FaderAppCell.h"
#import "FaderControl-Swift.h"
#import "macOSThemeKit-Swift.h"

// System Includes
#import <AVFoundation/AVCaptureDevice.h>


//#pragma clang assume_nonnull begin

static NSString* const kOptNoPersistentData  = @"--no-persistent-data";
static NSString* const kOptShowDockIcon      = @"--show-dock-icon";
@interface BGMAppDelegate () <MIKMIDIConnectionManagerDelegate>

@end

@implementation BGMAppDelegate {
    // The button in the system status bar that shows the main menu.
    BGMStatusBarItem* statusBarItem;
    
    // Only show the 'BGMXPCHelper is missing' error dialog once.
    BOOL haveShownXPCHelperErrorMessage;
    
    // Persistently stores user settings and data.
    BGMUserDefaults* userDefaults;
    
    BGMAutoPauseMusic* autoPauseMusic;
    //    BGMAutoPauseMenuItem* autoPauseMenuItem;
    BGMMusicPlayers* musicPlayers;
    BGMSystemSoundsVolume* systemSoundsVolume;
    BGMOutputDeviceMenuSection* outputDeviceMenuSection;
    BGMPreferencesMenu* prefsMenu;
    //    BGMDebugLoggingMenuItem* debugLoggingMenuItem;
    BGMXPCListener* xpcListener;
    BGMPreferredOutputDevices* preferredOutputDevices;
    
    NSInteger outputControlNumber;
    NSInteger inputControlNumber;
}

NSArray<NSNumber*>* controlNumbers = @[@0,@86,@2,@3,@4,@5,@6,@8,@9,@12];
NSArray<NSNumber*>* muteControlNumbers = @[@-1,@-1,@21,@22,@23,@24,@25,@26,@27,@28];
NSArray<NSNumber*>* unmuteControlNumbers = @[@-1,@-1,@29,@30,@31,@33,@34,@35,@36,@37];

@synthesize audioDevices = audioDevices;
@synthesize appVolumes = appVolumes;

- (void) awakeFromNib {
    [super awakeFromNib];
    
    //    [[NSUserDefaults standardUserDefaults] removePersistentDomainForName:(NSString *)[NSBundle mainBundle].bundleIdentifier];
    //    [[NSUserDefaults standardUserDefaults] synchronize];
    // Show BGMApp in the dock, if the command-line option for that was passed. This is used by the
    // UI tests.
    if ([NSProcessInfo.processInfo.arguments indexOfObject:kOptShowDockIcon] != NSNotFound) {
        [NSApp setActivationPolicy:NSApplicationActivationPolicyRegular];
    }
    
    haveShownXPCHelperErrorMessage = NO;
    
    // Set up audioDevices, which coordinates BGMDevice and the output device. It manages
    // playthrough, volume/mute controls, etc.
    if (![self initAudioDeviceManager]) {
        return;
    }
    
    [self.connectedButton setTitle:@"Not Connected"];
    self.connectedButton.image = nil;
    
    _connectionManager = [[MIKMIDIConnectionManager alloc] initWithName:@"com.mixedinkey.MIDITestbed.ConnectionManager" delegate:self eventHandler:^(MIKMIDISourceEndpoint *source __unused, NSArray<MIKMIDICommand *> *commands) {
        for (MIKMIDIChannelVoiceCommand *command in commands) { [self handleMIDICommand:command]; }
    }];
    _connectionManager.automaticallySavesConfiguration = NO;
    
    // Stored user settings
    userDefaults = [self createUserDefaults];
    
    // Get input and output control number
    inputControlNumber = userDefaults.inputControlNumber;
    outputControlNumber = userDefaults.outputControlNumber;
    
    NSUInteger inputIndex = [self comboIndexForControlNumber:inputControlNumber];
    [self.faderInputCombo setStringValue:self.faderInputCombo.objectValues[inputIndex]];
    
    NSUInteger outputIndex = [self comboIndexForControlNumber:outputControlNumber];
    [self.faderOutputCombo setStringValue:self.faderOutputCombo.objectValues[outputIndex]];
    
    // Add the status bar item. (The thing you click to show BGMApp's main menu.)
    statusBarItem = [[BGMStatusBarItem alloc] initWithMenu:self.bgmMenu
                                              audioDevices:audioDevices
                                              userDefaults:userDefaults];
}

- (void) handleMIDICommand:(MIKMIDICommand *)command
{
    NSLog(@"MIDI Command: %@", command.description);
    if ([command isKindOfClass:[MIKMIDIControlChangeCommand class]]){
        MIKMIDIControlChangeCommand* changeCommand = (MIKMIDIControlChangeCommand*) command;
        
        float value = (float) ((float)changeCommand.value/(float)127);
        [self processCommand:changeCommand.controllerNumber controlValue:value];
    }
}

- (void) processCommand:(NSUInteger) controllerNumber
           controlValue: (float)value
{
    //if command is mute
    if ([muteControlNumbers containsObject:[[NSNumber alloc] initWithInteger:controllerNumber]])
    {
        //get control command against mute command
        NSUInteger controlNumber = [self controlNumberForMuteControl:controllerNumber];
        
        //check if it matches input or output control
        if (controlNumber == inputControlNumber) //if input control
        {
            [self setMicVolume:0];
        } else if (controlNumber == outputControlNumber) // if output control
        {
            [self.outputVolume setVolume:0];
        } else { //its an app control
            //propogate command value to apps
            int appIndex = -1;
            for (int i=0;i<self.appsList.count;i++)
            {
                if (self.appsList[i].controlNubmer == controlNumber)
                {
                    appIndex = i;
                    break;
                }
            }
            
            if (appIndex != -1)
            {
                [appVolumes setVolume:0 forAppWithProcessID:self.appsList[appIndex].processIdentifier bundleID:self.appsList[appIndex].bundleIdentifier];
            }
        }
    }
    //if command is mute
    else if ([unmuteControlNumbers containsObject:[[NSNumber alloc] initWithInteger:controllerNumber]])
    {
        //get control command against mute command
        NSUInteger controlNumber = [self controlNumberForMuteControl:controllerNumber];
        
        //check if it matches input or output control
        if (controlNumber == inputControlNumber) //if input control
        {
            [self setMicVolume:value];
        } else if (controlNumber == outputControlNumber) // if output control
        {
            [self.outputVolume setVolume:value];
        } else { //its an app control
            //propogate command value to apps
            int appIndex = -1;
            for (int i=0;i<self.appsList.count;i++)
            {
                if (self.appsList[i].controlNubmer == controlNumber)
                {
                    appIndex = i;
                    break;
                }
            }
            
            if (appIndex != -1)
            {
                [appVolumes setVolumeForApp:self.appsList[appIndex]];
            }
        }
    }
    else if ([controlNumbers containsObject:[[NSNumber alloc] initWithInteger:controllerNumber]]){ //command not mute and a valid command
        if (controllerNumber == inputControlNumber) //if input control
        {
            [self setMicVolume:value];
        } else if (controllerNumber == outputControlNumber) // if output control
        {
            [self.outputVolume setVolume:value];
        } else { //its an app control
            //propogate command value to apps
            int appIndex = -1;
            for (int i=0;i<self.appsList.count;i++)
            {
                if (self.appsList[i].controlNubmer == controllerNumber)
                {
                    appIndex = i;
                    break;
                }
            }
            
            if (appIndex != -1)
            {
                int appVolume = (int) (value * 50.0f);
                self.appsList[appIndex].volume = appVolume;
                [appVolumes setVolumeForApp:self.appsList[appIndex]];
            }
        }
    }
}

// Connection Manager Delegate
- (void)connectionManager:(MIKMIDIConnectionManager *)manager deviceWasConnected:(MIKMIDIDevice *)device {
    NSLog(@"Log: MIDI Devices Connected: %@", device.description);
    [self.connectedButton setTitle:@"  Connected"];
    [self.connectedButton setImage:[NSImage imageNamed:@"NSMenuOnStateTemplate"]];
}

- (void)connectionManager:(MIKMIDIConnectionManager *)manager deviceWasDisconnected:(MIKMIDIDevice *)device withUnterminatedNoteOnCommands:(NSArray<MIKMIDINoteOnCommand *> *)commands {
    NSLog(@"Log: MIDI Devices Disconnected: %@", device.description);
    [self.connectedButton setImage:nil];
    [self.connectedButton setTitle:@"  Not Connected"];
}

- (MIKMIDIAutoConnectBehavior)connectionManager:(MIKMIDIConnectionManager *)manager shouldConnectToNewlyAddedDevice:(MIKMIDIDevice *)device {
    return MIKMIDIAutoConnectBehaviorConnectIfPreviouslyConnectedOrNew;
}
//End Connection Manager Delegate

- (void)appControlUpdated:(NSNotification *)notification
{
    NSInteger controlNumber = ((NSNumber*)notification.object).integerValue;
    
    NSLog(@"Log: appControlUpdated called with controlNumber %ld", controlNumber);
    
    if (inputControlNumber == controlNumber)
    {
        NSLog(@"Log: input sound control unassigned controlNumer: %ld", controlNumber);
        inputControlNumber = 0;
        [userDefaults setInputControlNumber:0];
        //set input volume to max
        //        [self setMicVolume:1.0];
        [self.faderInputCombo setStringValue:self.faderInputCombo.objectValues[0]];
    }else if (outputControlNumber == controlNumber)
    {
        NSLog(@"Log: output sound control unassigned controlNumer: %ld", controlNumber);
        outputControlNumber = 0;
        [userDefaults setOutputControlNumber:0];
        //set input volume to max
        //        [self.outputVolume setVolume:1.0];
        [self.faderOutputCombo setStringValue:self.faderOutputCombo.objectValues[0]];
    }
}

- (void) setMicVolume: (float) volume
{
    [NSSound setMicVolume:volume];
    if (volume == 0.0)
    {
        [self.faderInputMuteIcon setHidden:NO];
        [self.faderInputPercentage setHidden:YES];
        self.faderInputPercentage.stringValue = @"0%";
    } else {
        [self.faderInputMuteIcon setHidden:YES];
        [self.faderInputPercentage setHidden:NO];
        self.faderInputPercentage.stringValue = [[[NSString alloc] initWithFormat:@"%d", (int) (NSSound.micVolume*100)] stringByAppendingString:@"%"];
    }
}

//Input/Output Combobox Delegate Start
- (void)comboBoxSelectionDidChange:(NSNotification *)notification {
    NSComboBox* combo = (NSComboBox*) notification.object;
    if (combo == self.faderInputCombo) {
        NSLog(@"Combo faderInputCombo %ld", (long)self.faderInputCombo.indexOfSelectedItem);
        
        [self.faderInputCombo setStringValue:self.faderInputCombo.objectValues[self.faderInputCombo.indexOfSelectedItem]];
        NSInteger updatedControlNumber = [controlNumbers objectAtIndex:self.faderInputCombo.indexOfSelectedItem].integerValue;
        //save updated control number for input
        inputControlNumber = updatedControlNumber;
        [userDefaults setInputControlNumber:updatedControlNumber];
        
        NSLog(@"Log: input sound control assigned controlNumer: %ld", updatedControlNumber);
        
        if (updatedControlNumber != 0){
            if (outputControlNumber == updatedControlNumber)
            {
                NSLog(@"Log: output sound control unassigned controlNumer: %ld", outputControlNumber);
                [self.faderOutputCombo setStringValue:self.faderOutputCombo.objectValues[0]];
                //save updated control number for output
                outputControlNumber = 0;
                [userDefaults setOutputControlNumber:0];
            }
            
            //Adjust: Check app assigned to this control and unassign accordingly.
            [[NSNotificationCenter defaultCenter] postNotificationName:@"SystemControlUpdated" object:[[NSNumber alloc] initWithInteger:updatedControlNumber]];
        }
    } else if (combo == self.faderOutputCombo)
    {
        NSLog(@"Combo faderOutputCombo %ld", (long)self.faderOutputCombo.indexOfSelectedItem);
        [self.faderOutputCombo setStringValue:self.faderOutputCombo.objectValues[self.faderOutputCombo.indexOfSelectedItem]];
        NSInteger updatedControlNumber = [controlNumbers objectAtIndex:self.faderOutputCombo.indexOfSelectedItem].integerValue;
        //save updated control number for output
        outputControlNumber = updatedControlNumber;
        [userDefaults setOutputControlNumber:updatedControlNumber];
        
        NSLog(@"Log: output sound control assigned controlNumer: %ld", updatedControlNumber);
        
        if (updatedControlNumber != 0) {
            if (inputControlNumber == updatedControlNumber)
            {
                NSLog(@"Log: input sound control unassigned controlNumer: %ld", inputControlNumber);
                [self.faderInputCombo setStringValue:self.faderInputCombo.objectValues[0]];
                //save updated control number for input
                inputControlNumber = 0;
                [userDefaults setInputControlNumber:0];
            }
            
            //Adjust: Check app assigned to this control and unassign accordingly.
            [[NSNotificationCenter defaultCenter] postNotificationName:@"SystemControlUpdated" object:[[NSNumber alloc] initWithInteger:updatedControlNumber]];
        }
    } else if (combo == self.valueInput) {
        NSInteger controlIndex = [self.controlInput indexOfSelectedItem];
        if (controlIndex != 0) {
            
            float value = 0.0;
            int controlNumber = controlNumbers[controlIndex].unsignedIntValue;
            
            if ([self.valueInput indexOfSelectedItem] == 1){
                value = 0.5;
            } else if ([self.valueInput indexOfSelectedItem] == 2) {
                value = 1.0;
            }
            
            NSLog(@"Log: test input value: %f", value);
            [self processCommand:controlNumber controlValue:value];
        }
    }
}

- (NSUInteger)comboIndexForControlNumber:(NSUInteger)controlNumber {
    NSUInteger index = [controlNumbers indexOfObject:[[NSNumber alloc] initWithInteger:controlNumber]];
    return index;
}

//- (int)controlNumberForMute:(int)muteNumberIndex {
//    return [controlNumbers objectAtIndex:muteNumberIndex].intValue;
//}

- (NSUInteger)controlNumberForMuteControl:(NSUInteger)muteControlNumber {
    NSUInteger muteIndex = [muteControlNumbers indexOfObject:[[NSNumber alloc] initWithInteger:muteControlNumber]];
    return [controlNumbers objectAtIndex:muteIndex].integerValue;
}

- (NSUInteger)controlNumberForUnMuteControl:(NSUInteger)unmuteControlNumber {
    NSUInteger muteIndex = [unmuteControlNumbers indexOfObject:[[NSNumber alloc] initWithInteger:unmuteControlNumber]];
    return [controlNumbers objectAtIndex:muteIndex].integerValue;
}

//End Input/Output Combobox Delegate Start

//Fader Menu Buttons Actions
- (IBAction) settingsBtnClicked:(id)sender {
    
    if (self.settingsMenu.isHidden) {
        [self.settingsMenu setHidden:NO];
    } else {
        [self.settingsMenu setHidden:YES];
    }
}

- (IBAction)startOnLoginAction:(id)sender {
    NSString *appPath =[[NSBundle mainBundle] bundlePath] ;
    NSString *scriptPath = [[NSBundle mainBundle] pathForResource:@"AddToLogin" ofType:@"scpt"];

    NSArray *argArray;
    if(scriptPath)
    {
        argArray = [NSArray arrayWithObjects:scriptPath, appPath, nil];
        NSTask * task = [[NSTask alloc] init];
        [task setLaunchPath:@"/usr/bin/osascript"];
        [task setArguments:argArray];
        [task launch];
        [task waitUntilExit];
    }
}

- (IBAction)quitAction:(id)sender {
    [NSApp terminate:self];
}

- (IBAction) chooseAppClicked:(id)sender {
    NSOpenPanel *panel = [NSOpenPanel openPanel];
    NSArray  * fileTypes = [NSArray arrayWithObjects:@"app", nil];
    [panel setAllowedFileTypes:fileTypes];
    [panel setCanChooseFiles:YES];
    [panel setDirectoryURL:[[NSURL alloc] initWithString:@"/Applications"]];
    [panel setCanChooseDirectories:NO];
    [panel setAllowsMultipleSelection:NO]; // yes if more than one dir is allowed
    [panel setLevel:NSPopUpMenuWindowLevel];
    
    if ([panel runModal] == NSFileHandlingPanelOKButton) {
        for (NSURL *url in [panel URLs]) {
            //             do something with the url here.
            NSLog(@"APP: path: %@",url.path);
            NSLog(@"APP: url: %@",url.filePathURL);
            NSString* path = url.path;
            
            NSString* appName = [[url.filePathURL lastPathComponent]  stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@".app"]];
            NSLog(@"APP: appName: %@",appName);
            
            NSBundle * appBundle = [NSBundle bundleWithPath:path];
            
            NSString *bundleIdentifier = [[NSBundle mainBundle] bundleIdentifier];

            if (appBundle.bundleIdentifier == (id)[NSNull null])
            {
                
            } if (appBundle.bundleIdentifier == bundleIdentifier) {
                
            } else {
                if ([self appExists:appBundle.bundleIdentifier])
                {
                    NSLog(@"App Already Exists with bundleIdentifier: %@",appBundle.bundleIdentifier);
                } else {
                    NSLog(@"APP: bundleIdentifier: %@",appBundle.bundleIdentifier);
                    
                    NSImage* appIcon = [[NSWorkspace sharedWorkspace] iconForFile:path];
                    NSLog(@"APP: appIcon: %@",appIcon.description);
                    
                    BGMAppModel* app = [[BGMAppModel alloc] init];
                    app.title = appName;
                    app.icon = appIcon.TIFFRepresentation;
                    app.bundleIdentifier = (NSString*) appBundle.bundleIdentifier;
                    
                    NSArray<NSRunningApplication*>* runningApps = [NSRunningApplication runningApplicationsWithBundleIdentifier:app.bundleIdentifier];
                    
                    if (runningApps.count != 0)
                    {
                        app.processIdentifier = runningApps[0].processIdentifier;
                    }
                    
                    [ self.appsList insertObject:app atIndex:0];
                    [userDefaults setAppsList:self.appsList];
                    [appVolumes insertApp:0];
                }
            }
        }
    }
}

- (BOOL)appExists:(NSString *)bundleIndentifier {
    BOOL exists = NO;
    
    for (int i=0;i<_appsList.count; i++)
    {
        if ([_appsList[i].bundleIdentifier isEqual:bundleIndentifier])
        {
            exists = YES;
            break;
        }
    }
    return exists;
}

- (void) applicationDidFinishLaunching:(NSNotification*)aNotification {
#pragma unused (aNotification)
    
    // Apply the dark theme
    TKDarkTheme *darkTheme = TKThemeManager.darkTheme;
    [[TKThemeManager sharedManager] setTheme:darkTheme];
    
    //Get Connected MIDI Device
    NSArray<MIKMIDIDevice *> *devices = MIKMIDIDeviceManager.sharedDeviceManager.availableDevices;
    NSLog(@"MIDI Devices: %@", devices.description);
    if (devices.count > 0)
    {
        MIKMIDIDevice *device = devices[0];
        if (device.isVirtual)
        {
            NSLog(@"MIDI isVirtual YES");
        }else{
            NSLog(@"MIDI isVirtual NO");
        }
        
        NSError *error = nil;
        if (![self.connectionManager connectToDevice:device error:&error]) {
            //[NSApp presentError:error];
            NSLog(@"MIDI Connectoin Error %@" , error.localizedDescription);
        }
    }
    
    //add observer to get ControlUpdated notification if app control updated
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appControlUpdated:) name:@"AppControlUpdated" object:nil];
    
    // Log the version/build number.
    //
    // TODO: NSLog should only be used for logging errors.
    // TODO: Automatically add the commit ID to the end of the build number for unreleased builds. (In the
    //       Info.plist or something -- not here.)
    NSLog(@"BGMApp version: %@, BGMApp build number: %@",
          NSBundle.mainBundle.infoDictionary[@"CFBundleShortVersionString"],
          NSBundle.mainBundle.infoDictionary[@"CFBundleVersion"]);
    
    // Handles changing (or not changing) the output device when devices are added or removed. Must
    // be initialised before calling setBGMDeviceAsDefault.
    preferredOutputDevices =
    [[BGMPreferredOutputDevices alloc] initWithDevices:audioDevices userDefaults:userDefaults];
    
    // Skip this if we're compiling on a version of macOS before 10.14 as won't compile and it
    // isn't needed.
#if MAC_OS_X_VERSION_MAX_ALLOWED >= 101400  // MAC_OS_X_VERSION_10_14
    if (@available(macOS 10.14, *)) {
        // On macOS 10.14+ we need to get the user's permission to use input devices before we can
        // use BGMDevice for playthrough (see BGMPlayThrough), so we wait until they've given it
        // before making BGMDevice the default device. This way, if the user is playing audio when
        // they open Background Music, we won't interrupt it while we're waiting for them to click
        // OK.
        [AVCaptureDevice requestAccessForMediaType:AVMediaTypeAudio
                                 completionHandler:^(BOOL granted) {
            dispatch_async(dispatch_get_main_queue(), ^{
                if (granted) {
                    DebugMsg("BGMAppDelegate::applicationDidFinishLaunching: Permission granted");
                    [self continueLaunchAfterInputDevicePermissionGranted];
                } else {
                    NSLog(@"BGMAppDelegate::applicationDidFinishLaunching: Permission denied");
                    // If they don't accept, Background Music won't work at all and the only way to
                    // fix it is in System Preferences, so show an error dialog with instructions.
                    //
                    // TODO: It would be nice if this dialog had a shortcut to open the System
                    //       Preferences panel. See showSetDeviceAsDefaultError.
                    [self showErrorMessage:@"Background Music needs permission to use microphones."
                           informativeText:@"It uses a virtual microphone to access your system's "
                     "audio.\n\nYou can grant the permission by going to "
                     "System Preferences > Security and Privacy > "
                     "Microphone and checking the box for Background Music."
                 exitAfterMessageDismissed:YES];
                }
            });
        }];
    }
    else
#endif
    {
        // We can change the device immediately on older versions of macOS because they don't
        // require user permission for input devices.
        [self continueLaunchAfterInputDevicePermissionGranted];
    }
}

- (void)applicationDidBecomeActive:(NSNotification *)notification {
    [NSMenu setMenuBarVisible:YES];
}

- (void)application:(NSApplication *)application didUpdateUserActivity:(NSUserActivity *)userActivity {
    [NSMenu setMenuBarVisible:YES];
}

- (void) continueLaunchAfterInputDevicePermissionGranted {
    // Choose an output device for BGMApp to use to play audio.
    if (![self setInitialOutputDevice]) {
        return;
    }
    
    // Make BGMDevice the default device.
    [self setBGMDeviceAsDefault];
    
    // Handle some of the unusual reasons BGMApp might have to exit, mostly crashes.
    BGMTermination::SetUpTerminationCleanUp(audioDevices);
    
    // Set up the rest of the UI and other external interfaces.
    musicPlayers = [[BGMMusicPlayers alloc] initWithAudioDevices:audioDevices
                                                    userDefaults:userDefaults];
    
    //autoPauseMusic = [[BGMAutoPauseMusic alloc] initWithAudioDevices:audioDevices
    //                                                    musicPlayers:musicPlayers];
    
    [self setUpMainMenu];
    
    xpcListener = [[BGMXPCListener alloc] initWithAudioDevices:audioDevices
                                  helperConnectionErrorHandler:^(NSError* error) {
        NSLog(@"BGMAppDelegate::continueLaunchAfterInputDevicePermissionGranted: "
              "(helperConnectionErrorHandler) BGMXPCHelper connection error: %@",
              error);
        [self showXPCHelperErrorMessage:error];
    }];
}

// Returns NO if (and only if) BGMApp is about to terminate because of a fatal error.
- (BOOL) initAudioDeviceManager {
    audioDevices = [BGMAudioDeviceManager new];
    
    if (!audioDevices) {
        [self showBGMDeviceNotFoundErrorMessageAndExit];
        return NO;
    }
    
    return YES;
}

// Returns NO if (and only if) BGMApp is about to terminate because of a fatal error.
- (BOOL) setInitialOutputDevice {
    AudioObjectID preferredDevice = [preferredOutputDevices findPreferredDevice];
    
    if (preferredDevice != kAudioObjectUnknown) {
        NSError* __nullable error = [audioDevices setOutputDeviceWithID:preferredDevice
                                                        revertOnFailure:NO];
        if (error) {
            // Show the error message.
            [self showFailedToSetOutputDeviceErrorMessage:BGMNN(error)
                                          preferredDevice:preferredDevice];
        }
    } else {
        // We couldn't find a device to use, so show an error message and quit.
        [self showOutputDeviceNotFoundErrorMessageAndExit];
        return NO;
    }
    
    return YES;
}

// Sets the "Background Music" virtual audio device (BGMDevice) as the user's default audio device.
- (void) setBGMDeviceAsDefault {
    NSError* error = [audioDevices setBGMDeviceAsOSDefault];
    
    if (error) {
        [self showSetDeviceAsDefaultError:error
                                  message:@"Could not set the Background Music device as your"
         "default audio device."
                          informativeText:@"You might be able to change it yourself."];
    }
}

- (void) menuWillOpen:(NSMenu*)menu {
    if (@available(macOS 10.16, *)) {
        // Set menu offset and check for any active menu items
        float menuOffset = 12.0;
        for (NSMenuItem* menuItem in self.bgmMenu.itemArray) {
            if (menuItem.state == NSControlStateValueOn && menuItem.indentationLevel == 0) {
                menuOffset += 10;
                break;
            }
        }
        
        // Align volume output device and slider
        //        for (NSView* subview in self.outputVolumeView.subviews) {
        //            CGRect newSubview = subview.frame;
        //            newSubview.origin.x = menuOffset;
        //            subview.frame = newSubview;
        //        }
        
        // Align system sounds and app volumes
        double appIconTitleOffset = 0;
        for (NSMenuItem* menuItem in self.bgmMenu.itemArray) {
            if (menuItem.view.subviews.count == 7 || menuItem.view.subviews.count == 3) {
                NSTextField* appTitle;
                NSImageView* appIcon;
                
                for (NSView* subview in menuItem.view.subviews) {
                    if (menuItem.view.subviews.count == 3) {
                        // System sounds
                        if ([subview isKindOfClass:[NSTextField class]]) {
                            appTitle = (NSTextField*)subview;
                        }
                        if ([subview isKindOfClass:[NSImageView class]]) {
                            appIcon = (NSImageView*)subview;
                        }
                    } else if (menuItem.view.subviews.count == 7) {
                        // App volumes
                        if ([subview isKindOfClass:[BGMAVM_AppNameLabel class]]) {
                            appTitle = (NSTextField*)subview;
                        }
                        if ([subview isKindOfClass:[BGMAVM_AppIcon class]]) {
                            appIcon = (NSImageView*)subview;
                        }
                    }
                }
                
                if (appIconTitleOffset == 0) {
                    appIconTitleOffset = appTitle.frame.origin.x - appIcon.frame.origin.x;
                }
                
                CGRect newAppIcon = appIcon.frame;
                newAppIcon.origin.x = menuOffset;
                appIcon.frame = newAppIcon;
                CGRect newAppTitle = appTitle.frame;
                newAppTitle.origin.x = menuOffset + appIconTitleOffset;
                appTitle.frame = newAppTitle;
            }
        }
    }
}

- (void) setUpMainMenu {
    
    _faderControlBottomMenuItem.view = _faderControlBottomView;
    
    //autoPauseMenuItem =
    //    [[BGMAutoPauseMenuItem alloc] initWithMenuItem:self.autoPauseMenuItemUnwrapped
    //                                    autoPauseMusic:autoPauseMusic
    //                                      musicPlayers:musicPlayers
    //                                      userDefaults:userDefaults];
    
    [self initVolumesMenuSection];
    
    // Output device selection.
    //outputDeviceMenuSection =
    //        [[BGMOutputDeviceMenuSection alloc] initWithBGMMenu:self.bgmMenu
    //                                               audioDevices:audioDevices
    //                                           preferredDevices:preferredOutputDevices];
    //[audioDevices setOutputDeviceMenuSection:outputDeviceMenuSection];
    
    // Preferences submenu.
    //    prefsMenu = [[BGMPreferencesMenu alloc] initWithBGMMenu:self.bgmMenu
    //                                               audioDevices:audioDevices
    //                                               musicPlayers:musicPlayers
    //                                              statusBarItem:statusBarItem
    //                                                 aboutPanel:self.aboutPanel
    //                                      aboutPanelLicenseView:self.aboutPanelLicenseView];
    
    // Enable/disable debug logging. Hidden unless you option-click the status bar icon.
    //    debugLoggingMenuItem =
    //        [[BGMDebugLoggingMenuItem alloc] initWithMenuItem:self.debugLoggingMenuItemUnwrapped];
    //    [statusBarItem setDebugLoggingMenuItem:debugLoggingMenuItem];
    
    // Handle events about the main menu. (See the NSMenuDelegate methods below.)
    self.bgmMenu.delegate = self;
}

- (BGMUserDefaults*) createUserDefaults {
    BOOL persistentDefaults =
    [NSProcessInfo.processInfo.arguments indexOfObject:kOptNoPersistentData] == NSNotFound;
    NSUserDefaults* wrappedDefaults = persistentDefaults ? [NSUserDefaults standardUserDefaults] : nil;
    return [[BGMUserDefaults alloc] initWithDefaults:wrappedDefaults];
}

- (void) initVolumesMenuSection {
    //Get input volume level
    if (NSSound.micVolume == 0){
        [self.faderInputPercentage setHidden:YES];
        [self.faderInputMuteIcon setHidden:NO];
    } else {
        [self.faderInputPercentage setHidden:NO];
        [self.faderInputMuteIcon setHidden:YES];
        self.faderInputPercentage.stringValue = [[[NSString alloc] initWithFormat:@"%d", (int) (NSSound.micVolume*100)] stringByAppendingString:@"%"];
    }
    
    // Create the menu item with the (main) output volume slider.
    _outputVolume =
    [[BGMOutputVolumeMenuItem alloc] initWithAudioDevices:audioDevices
                                                     view:self.faderControlView
                                          percentageLabel:self.faderOutputPercentage
                                                 muteIcon:self.faderOutputMuteIcon];
    [audioDevices setOutputVolumeMenuItem:_outputVolume];
    
    //    NSInteger headingIdx = [self.bgmMenu indexOfItemWithTag:kVolumesHeadingMenuItemTag];
    
    //Add it to the main menu below the "Volumes" heading.
    [self.bgmMenu insertItem:_outputVolume atIndex:0];
    
    // Add the volume control for system (UI) sounds to the menu.
    BGMAudioDevice uiSoundsDevice = [audioDevices bgmDevice].GetUISoundsBGMDeviceInstance();
    
    //systemSoundsVolume =
    //    [[BGMSystemSoundsVolume alloc] initWithUISoundsDevice:uiSoundsDevice
    //                                                     view:self.systemSoundsView
    //                                                   slider:self.systemSoundsSlider];
    
    //[self.bgmMenu insertItem:systemSoundsVolume.menuItem atIndex:(headingIdx + 2)];
    
    //fetch list of previously saved apps
    NSArray<BGMAppModel*> * apps = [userDefaults getAppsList];
    
    _appsList = apps.mutableCopy;
    
    for(int i=0;i<self.appsList.count;i++)
    {
        NSArray<NSRunningApplication*>* runningApps = [NSRunningApplication runningApplicationsWithBundleIdentifier:self.appsList[i].bundleIdentifier];
        
        NSLog(@"App: runningApps count is %lu for bundleIdentifier %@", (unsigned long)runningApps.count, self.appsList[i].bundleIdentifier);
        if (runningApps.count != 0)
        {
            self.appsList[i].processIdentifier = runningApps[0].processIdentifier;
        }else{
            self.appsList[i].processIdentifier = -1;
        }
        //Adjust: keep record of volume
        //        self.appsList[i].volume = 50;
    }
    
    // Add the app volumes to the menu.
    appVolumes = [[BGMAppVolumesController alloc] initWithMenu:self.bgmMenu
                                                 appVolumeView:self.faderAppView
                                                  audioDevices:audioDevices
                                                      appsList:self.appsList
                                                 controlNumber:controlNumbers
                                                  userDefaults:userDefaults];
}

- (void) applicationWillTerminate:(NSNotification*)aNotification {
#pragma unused (aNotification)
    
    DebugMsg("BGMAppDelegate::applicationWillTerminate");
    
    // Change the user's default output device back.
    NSError* error = [audioDevices unsetBGMDeviceAsOSDefault];
    
    [userDefaults setAppsList:self.appsList];
    
    if (error) {
        [self showSetDeviceAsDefaultError:error
                                  message:@"Failed to reset your system's audio output device."
                          informativeText:@"You'll have to change it yourself to get audio working again."];
    }
}

#pragma mark Error messages

- (void) showBGMDeviceNotFoundErrorMessageAndExit {
    // BGMDevice wasn't found on the system. Most likely, BGMDriver isn't installed. Show an error
    // dialog and exit.
    //
    // TODO: Check whether the driver files are in /Library/Audio/Plug-Ins/HAL? Might even want to
    //       offer to install them if not.
    [self showErrorMessage:@"Could not find the Background Music virtual audio device."
           informativeText:@"Make sure you've installed Background Music Device.driver to "
     "/Library/Audio/Plug-Ins/HAL and restarted coreaudiod (e.g. \"sudo "
     "killall coreaudiod\")."
 exitAfterMessageDismissed:YES];
}

- (void) showFailedToSetOutputDeviceErrorMessage:(NSError*)error
                                 preferredDevice:(BGMAudioDevice)device {
    NSLog(@"Failed to set initial output device. Error: %@", error);
    
    dispatch_async(dispatch_get_main_queue(), ^{
        NSAlert* alert = [NSAlert alertWithError:BGMNN(error)];
        alert.messageText = @"Failed to set the output device.";
        
        NSString* __nullable name = nil;
        BGM_Utils::LogAndSwallowExceptions(BGMDbgArgs, [&] {
            name = (__bridge NSString* __nullable)device.CopyName();
        });
        
        alert.informativeText =
        [NSString stringWithFormat:@"Could not start the device '%@'. (Error: %ld)",
         name, error.code];
        
        [alert runModal];
    });
}

- (void) showOutputDeviceNotFoundErrorMessageAndExit {
    // We couldn't find any output devices. Show an error dialog and exit.
    [self showErrorMessage:@"Could not find an audio output device."
           informativeText:@"If you do have one installed, this is probably a bug. Sorry about "
     "that. Feel free to file an issue on GitHub."
 exitAfterMessageDismissed:YES];
}

- (void) showXPCHelperErrorMessage:(NSError*)error {
    if (!haveShownXPCHelperErrorMessage) {
        haveShownXPCHelperErrorMessage = YES;
        
        // NSAlert should only be used on the main thread.
        dispatch_async(dispatch_get_main_queue(), ^{
            NSAlert* alert = [NSAlert new];
            
            // TODO: Offer to install BGMXPCHelper if it's missing.
            // TODO: Show suppression button?
            [alert setMessageText:@"Error connecting to BGMXPCHelper."];
            [alert setInformativeText:[NSString stringWithFormat:@"%s%s%@ (%lu)",
                                       "Make sure you have BGMXPCHelper installed. There are instructions in the "
                                       "README.md file.\n\n"
                                       "Background Music might still work, but it won't work as well as it could.",
                                       "\n\nDetails:\n",
                                       [error localizedDescription],
                                       [error code]]];
            [alert runModal];
        });
    }
}

- (void) showErrorMessage:(NSString*)message
          informativeText:(NSString*)informativeText
exitAfterMessageDismissed:(BOOL)fatal {
    // NSAlert should only be used on the main thread.
    dispatch_async(dispatch_get_main_queue(), ^{
        NSAlert* alert = [NSAlert new];
        [alert setMessageText:message];
        [alert setInformativeText:informativeText];
        
        // This crashes if built with Xcode 9.0.1, but works with versions of Xcode before 9 and
        // with 9.1.
        [alert runModal];
        
        if (fatal) {
            [NSApp terminate:self];
        }
    });
}

- (void) showSetDeviceAsDefaultError:(NSError*)error
                             message:(NSString*)msg
                     informativeText:(NSString*)info {
    dispatch_async(dispatch_get_main_queue(), ^{
        NSLog(@"%@ %@ Error: %@", msg, info, error);
        
        NSAlert* alert = [NSAlert alertWithError:error];
        alert.messageText = msg;
        alert.informativeText = info;
        
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Open Sound in System Preferences"];
        
        NSModalResponse buttonClicked = [alert runModal];
        
        if (buttonClicked != NSAlertFirstButtonReturn) {  // 'OK' is the first button.
            [self openSysPrefsSoundOutput];
        }
    });
}

- (void) openSysPrefsSoundOutput {
    SystemPreferencesApplication* __nullable sysPrefs =
    [SBApplication applicationWithBundleIdentifier:@"com.apple.systempreferences"];
    
    if (!sysPrefs) {
        NSLog(@"Could not open System Preferences");
        return;
    }
    
    // In System Preferences, go to the "Output" tab on the "Sound" pane.
    for (SystemPreferencesPane* pane : [sysPrefs panes]) {
        DebugMsg("BGMAppDelegate::openSysPrefsSoundOutput: pane = %s", [pane.name UTF8String]);
        
        if ([pane.id isEqualToString:@"com.apple.preference.sound"]) {
            sysPrefs.currentPane = pane;
            
            for (SystemPreferencesAnchor* anchor : [pane anchors]) {
                DebugMsg("BGMAppDelegate::openSysPrefsSoundOutput: anchor = %s", [anchor.name UTF8String]);
                
                if ([[anchor.name lowercaseString] isEqualToString:@"output"]) {
                    DebugMsg("BGMAppDelegate::openSysPrefsSoundOutput: Showing Output in Sound pane.");
                    
                    [anchor reveal];
                }
            }
        }
    }
    
    // Bring System Preferences to the foreground.
    [sysPrefs activate];
}

#pragma mark NSMenuDelegate

- (void) menuNeedsUpdate:(NSMenu*)menu {
    if ([menu isEqual:self.bgmMenu]) {
        //        [autoPauseMenuItem parentMenuNeedsUpdate];
    } else {
        DebugMsg("BGMAppDelegate::menuNeedsUpdate: Warning: unexpected menu. menu=%s", menu.description.UTF8String);
    }
}

- (void) menu:(NSMenu*)menu willHighlightItem:(NSMenuItem* __nullable)item {
    if ([menu isEqual:self.bgmMenu]) {
        //        [autoPauseMenuItem parentMenuItemWillHighlight:item];
    } else {
        DebugMsg("BGMAppDelegate::menu: Warning: unexpected menu. menu=%s", menu.description.UTF8String);
    }
}
@end

//#pragma clang assume_nonnull end

