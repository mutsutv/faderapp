//
//  FaderAppCell.h
//  FaderControl
//
//  Created by Zahid Usman on 13/10/2022.
//  Copyright © 2022 Background Music contributors. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface FaderAppCell : NSTableCellView

@property (weak) IBOutlet NSComboBox* faderCombo;
@property (weak) IBOutlet NSTextField* appName;
@property (weak) IBOutlet NSImageView* appIcon;

@end

NS_ASSUME_NONNULL_END
