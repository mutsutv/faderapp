//
//  FaderAppCell.m
//  FaderControl
//
//  Created by Zahid Usman on 13/10/2022.
//  Copyright © 2022 Background Music contributors. All rights reserved.
//

#import "FaderAppCell.h"

@implementation FaderAppCell

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

@end
