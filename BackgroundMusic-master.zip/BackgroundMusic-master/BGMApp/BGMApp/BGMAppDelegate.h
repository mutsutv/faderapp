// This file is part of Background Music.
//
// Background Music is free software: you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation, either version 2 of the
// License, or (at your option) any later version.
//
// Background Music is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Background Music. If not, see <http://www.gnu.org/licenses/>.

//
//  BGMAppDelegate.h
//  BGMApp
//
//  Copyright © 2016, 2017, 2020 Kyle Neideck
//  Copyright © 2021 Marcus Wu
//
//  Sets up and tears down the app.
//

// Local Includes
#import "BGMAudioDeviceManager.h"
#import "BGMAppVolumesController.h"
#import <MIKMIDI/MIKMIDI.h>
#import "BGMAppModel.h"

// System Includes
#import <Cocoa/Cocoa.h>

// Tags for UI elements in MainMenu.xib
static NSInteger const kVolumesHeadingMenuItemTag = 0;
static NSInteger const kSeparatorBelowVolumesMenuItemTag = 4;

@interface BGMAppDelegate : NSObject <NSApplicationDelegate, NSMenuDelegate, NSComboBoxDelegate>

@property (weak) IBOutlet NSMenu* bgmMenu;

@property (weak) IBOutlet NSView* faderControlView;
@property (weak) IBOutlet NSComboBox* faderInputCombo;
@property (weak) IBOutlet NSComboBox* faderOutputCombo;
@property (weak) IBOutlet NSTextField* faderOutputPercentage;
@property (weak) IBOutlet NSTextField* faderInputPercentage;
@property (weak) IBOutlet NSImageView* faderOutputMuteIcon;
@property (weak) IBOutlet NSImageView* faderInputMuteIcon;

@property (weak) IBOutlet NSView* faderControlBottomView;
@property (weak) IBOutlet NSView* faderAppView;

//@property (weak) IBOutlet NSView* outputVolumeView;
//@property (weak) IBOutlet NSTextField* outputVolumeLabel;
//@property (weak) IBOutlet NSSlider* outputVolumeSlider;

@property (weak) IBOutlet NSView* systemSoundsView;
@property (weak) IBOutlet NSSlider* systemSoundsSlider;

@property (weak) IBOutlet NSView* appVolumeView;

@property (weak) IBOutlet NSPanel* aboutPanel;
@property (unsafe_unretained) IBOutlet NSTextView* aboutPanelLicenseView;

//@property (weak) IBOutlet NSMenuItem* autoPauseMenuItemUnwrapped;
//@property (weak) IBOutlet NSMenuItem* debugLoggingMenuItemUnwrapped;

//@property (weak) IBOutlet NSMenuItem* faderControlAppMenuItem;
@property (weak) IBOutlet NSMenuItem* faderControlBottomMenuItem;

@property (readonly) BGMAudioDeviceManager* audioDevices;
@property (readonly) BGMOutputVolumeMenuItem* outputVolume;
@property BGMAppVolumesController* appVolumes;
@property NSMutableArray<BGMAppModel*>* appsList;
@property (nonatomic, strong) MIKMIDIConnectionManager *connectionManager;

@property (weak) IBOutlet NSComboBox* controlInput;
@property (weak) IBOutlet NSComboBox* valueInput;
@property (weak) IBOutlet NSBox *settingsMenu;
@property (weak) IBOutlet NSButton *startOnLoginButton;
@property (weak) IBOutlet NSButton *connectedButton;


- (BOOL) appExists: (NSString*) bundleIndentifier;
@end

